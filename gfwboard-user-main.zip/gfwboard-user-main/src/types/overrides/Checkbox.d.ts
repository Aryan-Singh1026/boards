// eslint-disable-next-line
import * as Checkbox from '@mui/material/Checkbox';

declare module '@mui/material/Checkbox' {
  interface CheckboxPropsSizeOverrides {
    large;
  }
}
