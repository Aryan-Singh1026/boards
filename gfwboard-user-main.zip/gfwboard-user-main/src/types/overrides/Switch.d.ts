// eslint-disable-next-line
import * as Switch from '@mui/material/Switch';

declare module '@mui/material/Switch' {
  interface SwitchPropsSizeOverrides {
    large;
  }
}
