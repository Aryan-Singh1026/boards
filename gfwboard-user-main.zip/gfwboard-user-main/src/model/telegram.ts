export interface TelegramBotInfo {
  username: string;
}
