export interface RegisterPayload {
  email: string;
  password: string;
  invite_code: string;
  email_code: string;
}
