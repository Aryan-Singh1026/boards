export interface WithdrawPayload {
  withdraw_account: string;
  withdraw_method: string;
}
