export type ResetPasswordPayload = {
  email: string;
  password: string;
  email_code: string;
};
