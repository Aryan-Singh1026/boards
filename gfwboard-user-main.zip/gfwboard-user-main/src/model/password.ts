export interface ChangePasswordPayload {
  old_password: string;
  new_password: string;
}
