export default interface SendMailPayload {
  email: string;
  recaptcha_data?: string;
}
